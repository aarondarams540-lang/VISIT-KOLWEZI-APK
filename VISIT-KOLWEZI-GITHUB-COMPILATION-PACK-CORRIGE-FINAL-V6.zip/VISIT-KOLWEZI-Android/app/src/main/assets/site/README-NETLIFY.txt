VISIT KOLWEZI — prêt pour Netlify Drop

1. Décompressez le ZIP.
2. Ouvrez le dossier VISIT-KOLWEZI-NETLIFY.
3. Déposez ce dossier (avec index.html ET le dossier images) dans Netlify Drop.

IMPORTANT : ne séparez pas index.html du dossier images.
