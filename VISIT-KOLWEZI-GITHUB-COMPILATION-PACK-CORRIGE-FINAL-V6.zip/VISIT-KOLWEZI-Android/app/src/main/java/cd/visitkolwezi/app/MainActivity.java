package cd.visitkolwezi.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int LOCATION_REQUEST = 1001;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final String APP_NAME = "VISIT KOLWEZI";

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        showAnimatedSplash();
    }

    private void showAnimatedSplash() {
        FrameLayout splash = new FrameLayout(this);
        splash.setBackgroundColor(Color.rgb(11, 31, 42));

        TextView title = new TextView(this);
        title.setText("");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.08f);

        FrameLayout.LayoutParams titleParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        titleParams.gravity = Gravity.CENTER;
        titleParams.leftMargin = 24;
        titleParams.rightMargin = 24;
        splash.addView(title, titleParams);

        TextView subtitle = new TextView(this);
        subtitle.setText("Explorer Kolwezi autrement.");
        subtitle.setTextColor(Color.rgb(210, 220, 225));
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setAlpha(0f);

        FrameLayout.LayoutParams subParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        subParams.gravity = Gravity.CENTER;
        subParams.topMargin = 100;
        subParams.leftMargin = 24;
        subParams.rightMargin = 24;
        splash.addView(subtitle, subParams);

        setContentView(splash);

        final int[] index = {0};
        final StringBuilder typed = new StringBuilder();

        Runnable typeWriter = new Runnable() {
            @Override
            public void run() {
                if (index[0] < APP_NAME.length()) {
                    typed.append(APP_NAME.charAt(index[0]));
                    title.setText(typed.toString());
                    index[0]++;
                    handler.postDelayed(this, 105);
                } else {
                    subtitle.animate()
                            .alpha(1f)
                            .setDuration(500)
                            .setInterpolator(new DecelerateInterpolator())
                            .start();

                    handler.postDelayed(() -> {
                        splash.animate()
                                .alpha(0f)
                                .setDuration(550)
                                .setInterpolator(new DecelerateInterpolator())
                                .withEndAction(MainActivity.this::showMainPage)
                                .start();
                    }, 850);
                }
            }
        };

        // Petit fondu d'entrée avant l'écriture lettre par lettre.
        splash.setAlpha(0f);
        splash.animate()
                .alpha(1f)
                .setDuration(350)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> handler.postDelayed(typeWriter, 250))
                .start();
    }

    private void showMainPage() {
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.setAlpha(0f);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String scheme = u.getScheme();

                if ("file".equalsIgnoreCase(scheme)) {
                    return false;
                }

                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(
                    String origin,
                    GeolocationPermissions.Callback callback) {

                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED
                        && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {

                    requestPermissions(
                            new String[]{
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                            },
                            LOCATION_REQUEST
                    );
                }

                callback.invoke(origin, true, false);
            }
        });

        // Le site VISIT KOLWEZI est embarqué directement dans l'APK.
        // Aucune dépendance à Netlify pour afficher l'application.
        webView.loadUrl("file:///android_asset/site/index.html");
        webView.animate()
                .alpha(1f)
                .setDuration(450)
                .setInterpolator(new DecelerateInterpolator())
                .start();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
